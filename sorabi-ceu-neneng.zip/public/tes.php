<?php
echo "<h1>PHP Berjalan!</h1>";
phpinfo();